package utils;

public interface InfoGenerator{

    public void generateRandomInfo();
    
}